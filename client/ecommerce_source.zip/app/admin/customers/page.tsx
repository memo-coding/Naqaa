'use client';
import { useState, useEffect, useMemo } from 'react';
import { useLang } from '@/components/LanguageProvider';
import { useCMS } from '@/components/CMSProvider';
import { fetchApi } from '@/lib/api';

export default function CustomersDirectory() {
  const { t, dir } = useLang();

  const { data: cms } = useCMS();

  const [customers, setCustomers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Filters state
  const [searchQuery, setSearchQuery] = useState('');
  const [tierFilter, setTierFilter] = useState('all');
  const [sortBy, setSortBy] = useState('newest');

  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 10;

  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, tierFilter, sortBy]);

  useEffect(() => {
    async function fetchCustomers() {
      try {
        const profilesData = await fetchApi('/auth/users');
        const ordersData = await fetchApi('/orders');
        
        if (profilesData && Array.isArray(profilesData)) {
           const filteredProfiles = profilesData.filter((p: any) => p.role !== 'admin');
           setCustomers(filteredProfiles.map((p: any) => {
               const userOrders = ordersData?.filter((o: any) => o.user_id === p._id) || [];
               const spendNum = userOrders.reduce((sum: number, o: any) => sum + o.total_amount, 0);
               const orderCount = userOrders.length;
               
               // Find latest order for phone number mapping
               let phone = 'N/A';
               if (userOrders.length > 0) {
                 const sortedOrders = [...userOrders].sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
                 if (sortedOrders[0].shippingAddress && sortedOrders[0].shippingAddress.phone) {
                   phone = sortedOrders[0].shippingAddress.phone;
                 }
               }
               
               return {
                  id: p._id || p.id,
                  name: p.name || 'Customer',
                  email: p.email,
                  phone: phone,
                  createdAt: p.createdAt ? new Date(p.createdAt) : new Date(),
                  orderCount: orderCount,
                  spendNum: spendNum,
                  spend: `$${spendNum.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}`,
                  loyaltyKey: spendNum >= (cms.tierPlatinumThreshold || 1000) ? 'tier_platinum' : spendNum >= (cms.tierGoldThreshold || 500) ? 'tier_gold' : 'tier_new',
                  status: 'Active',
                  statusKey: 'status_active'
               };
           }));
        }
      } catch (err) {
        console.error('Failed to parse load customers:', err);
      }
      setLoading(false);
    }
    fetchCustomers();
  }, []);

  // Filter and Sort Customers
  const filteredCustomers = useMemo(() => {
    let result = [...customers];
    
    // Search Filter
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(c => c.name.toLowerCase().includes(q) || c.email.toLowerCase().includes(q) || c.phone.includes(q));
    }
    
    // Tier Filter
    if (tierFilter !== 'all') {
      result = result.filter(c => c.loyaltyKey === tierFilter);
    }
    
    // Sorting
    switch (sortBy) {
      case 'highest_spend':
        result.sort((a, b) => b.spendNum - a.spendNum);
        break;
      case 'most_orders':
        result.sort((a, b) => b.orderCount - a.orderCount);
        break;
      case 'oldest':
        result.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
        break;
      case 'newest':
      default:
        result.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
        break;
    }
    
    return result;
  }, [customers, searchQuery, tierFilter, sortBy]);

  const totalPages = Math.ceil(filteredCustomers.length / ITEMS_PER_PAGE);
  const paginatedCustomers = filteredCustomers.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);

  return (
    <div className="p-8 space-y-8 max-w-[1600px] mx-auto w-full" dir={dir}>
      <div className={`flex flex-col md:flex-row justify-between items-start md:items-center gap-6 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
        <div>
          <h2 className="text-4xl font-black font-headline tracking-tighter text-on-surface uppercase mb-1">{t('admin_customers_title') || 'Customers Directory'}</h2>
          <p className="text-on-surface-variant font-medium text-sm">{t('admin_customers_desc') || 'Manage and view all your customer data'}</p>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-surface-container-low p-6 rounded-3xl border border-white/5 shadow-sm flex flex-col lg:flex-row gap-6 justify-between items-center group">
         <div className="w-full lg:w-96 relative">
            <span className={`absolute top-1/2 -translate-y-1/2 ${dir === 'rtl' ? 'right-4' : 'left-4'} material-symbols-outlined text-on-surface-variant group-focus-within:text-primary transition-colors`}>search</span>
            <input 
              type="text" 
              placeholder={dir === 'rtl' ? 'البحث بالاسم، البريد أو الهاتف...' : 'Search by name, email, or phone...'} 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full bg-surface-container border border-white/10 rounded-xl py-3 ${dir === 'rtl' ? 'pr-12 pl-4 text-right' : 'pl-12 pr-4 text-left'} text-sm font-bold text-on-surface outline-none focus:border-primary/50 transition-all`}
            />
         </div>
         
         <div className="flex flex-wrap gap-4 w-full lg:w-auto">
            <div className={`flex bg-surface-container border border-white/10 rounded-xl p-1 shrink-0 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
               {['all', 'tier_platinum', 'tier_gold', 'tier_new'].map((tier) => (
                  <button 
                    key={tier}
                    onClick={() => setTierFilter(tier)}
                    className={`px-4 py-2 text-[10px] font-black uppercase tracking-widest rounded-lg transition-all ${tierFilter === tier ? 'bg-primary text-black shadow-[0_0_15px_rgba(145,247,142,0.3)]' : 'text-on-surface-variant hover:text-on-surface'}`}
                  >
                     {tier === 'all' ? (dir === 'rtl' ? 'الكل' : 'All') : t(tier)}
                  </button>
               ))}
            </div>
            
            <div className="relative shrink-0">
               <select 
                 value={sortBy}
                 onChange={(e) => setSortBy(e.target.value)}
                 className={`appearance-none bg-surface-container border border-white/10 rounded-xl py-3 ${dir === 'rtl' ? 'pl-4 pr-10' : 'pr-4 pl-10'} text-[10px] font-black tracking-widest uppercase text-on-surface outline-none focus:border-primary/50 cursor-pointer`}
               >
                 <option value="newest">{dir === 'rtl' ? 'الأحدث إنضماماً' : 'Newest Joined'}</option>
                 <option value="oldest">{dir === 'rtl' ? 'الأقدم إنضماماً' : 'Oldest Joined'}</option>
                 <option value="highest_spend">{dir === 'rtl' ? 'الأعلى إنفاقاً' : 'Highest Spend'}</option>
                 <option value="most_orders">{dir === 'rtl' ? 'الأكثر طلبات' : 'Most Orders'}</option>
               </select>
               <span className={`absolute top-1/2 -translate-y-1/2 ${dir === 'rtl' ? 'right-3' : 'left-3'} material-symbols-outlined text-on-surface-variant pointer-events-none text-lg`}>sort</span>
            </div>
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {loading ? (
          <div className="text-center py-8 text-on-surface-variant col-span-full">Loading...</div>
        ) : paginatedCustomers.length === 0 ? (
          <div className="text-center py-20 text-on-surface-variant col-span-full opacity-60">
             <span className="material-symbols-outlined text-6xl mb-4">search_off</span>
             <p className="text-sm font-bold uppercase tracking-widest">{dir === 'rtl' ? 'لم يتم العثور على عملاء' : 'No customers found'}</p>
          </div>
        ) : (
        paginatedCustomers.map((cust) => (
          <div key={cust.id} className="p-6 rounded-3xl bg-surface-container border border-white/5 hover:border-primary/20 transition-all group relative overflow-hidden shadow-sm flex flex-col h-full">
             <div className={`absolute top-0 ${dir === 'rtl' ? 'left-0 -ml-10' : 'right-0 -mr-10'} w-24 h-24 bg-primary/5 rounded-xl -mt-10 blur-2xl group-hover:bg-primary/10 transition-all`}></div>
             <div className={`relative z-10 flex justify-between items-start mb-6 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                <div className={`flex justify-start items-center gap-4 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary font-black uppercase text-xl shadow-[0_0_15px_rgba(145,247,142,0.1)] shrink-0 max-w-none">{cust.name[0]}</div>
                  <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                     <h4 className="font-headline font-black text-lg text-on-surface tracking-tight mb-0.5 whitespace-nowrap overflow-hidden text-ellipsis max-w-[150px]">{cust.name}</h4>
                     <p className="text-[9px] text-on-surface-variant font-bold uppercase tracking-widest whitespace-nowrap overflow-hidden text-ellipsis max-w-[150px]" dir="ltr">{cust.email}</p>
                  </div>
                </div>
                <span className={`px-3 py-1 text-[8px] font-black uppercase tracking-widest rounded-xl shrink-0 ${
                  cust.status === 'Active' ? 'bg-primary/10 text-primary' : 
                  cust.status === 'Inactive' ? 'bg-error/10 text-error' : 
                  'bg-secondary/10 text-secondary'
                }`}>{t(cust.statusKey)}</span>
             </div>
             
             <div className={`grid grid-cols-2 gap-4 mb-6 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                <div className="bg-surface-container-low p-3 rounded-xl border border-white/5">
                   <p className="text-[8px] text-on-surface-variant uppercase font-black tracking-widest mb-1">{dir === 'rtl' ? 'الهاتف' : 'Phone'}</p>
                   <p className="text-[10px] font-bold text-on-surface" dir="ltr">{cust.phone}</p>
                </div>
                <div className="bg-surface-container-low p-3 rounded-xl border border-white/5">
                   <p className="text-[8px] text-on-surface-variant uppercase font-black tracking-widest mb-1">{dir === 'rtl' ? 'تاريخ الانضمام' : 'Join Date'}</p>
                   <p className="text-[10px] font-bold text-on-surface">
                     {cust.createdAt.toLocaleDateString(dir === 'rtl' ? 'ar-EG' : 'en-US', { year: 'numeric', month: 'short', day: 'numeric' })}
                   </p>
                </div>
             </div>

             <div className={`mt-auto flex justify-between items-end pt-5 border-t border-white/5 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                 <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                    <p className="text-[8px] font-black uppercase tracking-[0.2em] text-on-surface-variant mb-1">{t('admin_lifetime_value')}</p>
                    <p className="text-sm font-black text-on-surface">{cust.spend}</p>
                 </div>
                 <div className={`text-center`}>
                    <p className="text-[8px] font-black uppercase tracking-[0.2em] text-on-surface-variant mb-1">{dir === 'rtl' ? 'الطلبات' : 'Orders'}</p>
                    <p className="text-sm font-black text-on-surface">{cust.orderCount}</p>
                 </div>
                <div className={dir === 'rtl' ? 'text-left' : 'text-right'}>
                   <p className="text-[8px] font-black uppercase tracking-[0.2em] text-on-surface-variant mb-1">{t('admin_tier')}</p>
                   <p className="text-[10px] font-black font-headline text-primary uppercase">{t(cust.loyaltyKey)}</p>
                </div>
             </div>
          </div>
        )))}
      </div>

      {/* Pagination Footer */}
      {totalPages > 1 && (
        <div className="flex justify-between items-center bg-surface-container-low p-4 rounded-2xl border border-white/5 shadow-sm mt-8">
          <div className="text-xs text-on-surface-variant font-medium">
             {t('admin_showing') || 'Showing'} {((currentPage - 1) * ITEMS_PER_PAGE) + 1} {t('admin_to') || 'to'} {Math.min(currentPage * ITEMS_PER_PAGE, filteredCustomers.length)} {t('admin_of') || 'of'} {filteredCustomers.length}
          </div>
          <div className={`flex items-center gap-2 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
             <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1} className="p-2 flex items-center justify-center text-on-surface-variant hover:text-primary disabled:opacity-30 transition-colors"><span className="material-symbols-outlined text-sm">chevron_left</span></button>
             <div className="flex gap-1.5 hidden md:flex">
                {Array.from({length: totalPages}, (_, i) => i + 1).map(page => (
                   <button 
                     key={page} 
                     onClick={() => setCurrentPage(page)} 
                     className={`w-8 h-8 rounded-lg text-xs font-black transition-all ${currentPage === page ? 'bg-primary text-black shadow-[0_0_10px_rgba(145,247,142,0.3)]' : 'bg-surface-container hover:bg-white/5 text-on-surface-variant border border-white/5'}`}
                   >
                     {page}
                   </button>
                ))}
             </div>
             <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="p-2 flex items-center justify-center text-on-surface-variant hover:text-primary disabled:opacity-30 transition-colors"><span className="material-symbols-outlined text-sm">chevron_right</span></button>
          </div>
        </div>
      )}
    </div>
  );
}
